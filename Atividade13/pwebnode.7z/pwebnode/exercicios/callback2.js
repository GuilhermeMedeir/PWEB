function exibeNaOrdem(mensagem, callback) {
    console.log(mensagem);
    callback();
}
exibeNaOrdem('essa é a primeira', function () { console.log('essa a segunda') });