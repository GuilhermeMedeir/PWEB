const prompt = require('prompt-sync')();
function saudacao(nome){
    console.log('oi ' + nome);
}

function entranome(callback){
    let nome = prompt("digite seu nome:");
    callback(nome);
}
entranome(saudacao);