let jogada;
let computador;
let resultadoComputador;

let pedra = "pedra";
let papel = "papel";
let tesoura = "tesoura";
let denovo = 0;


do{
    jogada = 0;
    resultadoComputador = 0;
    
    jogada = prompt("pedra, papel ou tesoura? digite 0 para parar").toLowerCase();
    if (jogada == 0) {
        denovo = 1;
        break;
    }
    
    computador = Math.random();
    if (computador < 0.33) {
        resultadoComputador = pedra;
    }
    else if (computador <= 0.66) {
        resultadoComputador = papel;
    }
    else {
        resultadoComputador = tesoura;
    }
    alert("O computador jogou: " + resultadoComputador + " e " + computador);
    
    if (jogada == resultadoComputador) {
        alert("Empate!");
    } else if (
        (jogada == pedra && resultadoComputador == tesoura) ||
        (jogada == papel && resultadoComputador == pedra) ||
        (jogada == tesoura && resultadoComputador == papel)
    ) {
        alert("Você VENCEU!");
    } else {
        alert("Você PERDEU!");
    } 
    
} while (denovo == 0);