let http = require('http');
let server = http.createServer(function (req, res) {
    let opcao = req.url;
    if (opcao == '/historia') {
        res.end("<html><body>site da fatec sorocaba</body></html>");
    }
    else if (opcao == '/cursos') {
        res.end("<html><body>cursos</body></html>");
    }
    else if (opcao == '/professores') {
        res.end("<html><body>professores</body></html>");
    }
});
server.listen(3000);